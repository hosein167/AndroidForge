package com.sarallah.player

import android.app.*
import android.content.*
import android.graphics.Color
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.*
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private val green = Color.rgb(5, 65, 49)
    private val dark = Color.rgb(3, 43, 34)
    private val gold = Color.rgb(220, 183, 99)
    private val cream = Color.rgb(245, 239, 220)
    private lateinit var player: ExoPlayer
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var playButton: Button
    private lateinit var volumeBar: SeekBar
    private lateinit var category: Spinner
    private var tracks = mutableListOf<Uri>()
    private var names = mutableListOf<String>()
    private var activeCategory = "همه"
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var fadeRunnable: Runnable? = null
    private var sleepRunnable: Runnable? = null
    private var sleepTimer: CountDownTimer? = null
    private var fading = false
    private var repeatOne = false
    private var shuffle = false
    private var savedVolume = 1f
    private val prefs by lazy { getSharedPreferences("sarallah", MODE_PRIVATE) }

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (!tracks.contains(uri)) {
                    tracks.add(uri)
                    names.add(queryName(uri))
                }
            }
            persistTracks()
            refreshList()
            status.text = "${uris.size} فایل اضافه شد"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                updateCurrent()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && repeatOne) player.seekTo(0)
                updatePlayButton()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayButton()
        })
        loadTracks()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val brand = TextView(this).apply {
            text = "✦ ثارالله ✦"
            textSize = 30f; setTextColor(gold); gravity = Gravity.CENTER
            setPadding(dp(8)); typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
        }
        content.addView(brand, matchWrap())
        val subtitle = TextView(this).apply {
            text = "پخش‌کننده همراه موکب"; textSize = 14f; setTextColor(cream); gravity = Gravity.CENTER
            setPadding(dp(2), 0, dp(2), dp(12))
        }
        content.addView(subtitle, matchWrap())
        val add = button("＋ افزودن مداحی از گوشی") { pickAudio.launch(arrayOf("audio/*")) }
        content.addView(add, matchWrap())
        category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("همه", "شور", "واحد", "زمینه", "روضه", "سخنرانی"))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    activeCategory = listOf("همه", "شور", "واحد", "زمینه", "روضه", "سخنرانی")[position]
                    refreshList()
                }
            }
        }
        content.addView(category, matchWrap())
        val nowCard = card()
        title = TextView(this).apply {
            text = "مداحی انتخاب نشده"; textSize = 20f; setTextColor(gold); gravity = Gravity.CENTER
            setPadding(dp(12))
        }
        status = TextView(this).apply {
            text = "برای شروع، فایل صوتی اضافه کن"; textSize = 13f; setTextColor(cream); gravity = Gravity.CENTER
            setPadding(dp(4))
        }
        nowCard.addView(title, matchWrap()); nowCard.addView(status, matchWrap())
        content.addView(nowCard, matchWrap())
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("قبلی") { previous() })
        playButton = button("▶ پخش") { if (player.isPlaying) player.pause() else if (player.mediaItemCount == 0 && tracks.isNotEmpty()) playAt(0) else player.play() }
        controls.addView(playButton)
        controls.addView(button("بعدی") { next(true) })
        content.addView(controls, matchWrap())
        val secondary = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        secondary.addView(button("توقف") { player.stop(); updatePlayButton() })
        secondary.addView(button(if (shuffle) "تصادفی ✓" else "تصادفی") { shuffle = !shuffle; (it as Button).text = if (shuffle) "تصادفی ✓" else "تصادفی" })
        secondary.addView(button("تکرار") { repeatOne = !repeatOne; (it as Button).text = if (repeatOne) "تکرار ✓" else "تکرار" })
        content.addView(secondary, matchWrap())
        content.addView(section("فهرست پخش"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox, matchWrap())
        content.addView(section("تنظیم صدا"))
        content.addView(label("بلندی صدای خروجی"))
        volumeBar = SeekBar(this).apply {
            max = 100; progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) { savedVolume = p / 100f; player.volume = savedVolume } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        content.addView(volumeBar, matchWrap())
        content.addView(label("اکولایزر پنج‌باندی (در صورت پشتیبانی گوشی)"))
        content.addView(label("بیس ۸۰Hz: ضرب و کوبش پایین صدا"))
        content.addView(eqSlider(0))
        content.addView(label("بم ۲۵۰Hz: گرمی و پر بودن صدا"))
        content.addView(eqSlider(1))
        content.addView(label("میانی ۱kHz: بدنه و حضور صدای مداح"))
        content.addView(eqSlider(2))
        content.addView(label("وضوح ۴kHz: وضوح کلمات و جزئیات"))
        content.addView(eqSlider(3))
        content.addView(label("زیر ۱۰kHz: تیزی و درخشش صدا"))
        content.addView(eqSlider(4))
        content.addView(label("تقویت بیس"))
        content.addView(eqFeatureSlider { value -> bass?.let { safeSetBass(it, value) } })
        content.addView(label("فضاسازی صدا"))
        content.addView(eqFeatureSlider { value -> virtualizer?.let { safeSetVirtual(it, value) } })
        content.addView(section("امکانات موکب"))
        val soft = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        soft.addView(button("کم‌کردن نرم صدا") { fadeVolume(0f, 1800) })
        soft.addView(button("بازگرداندن صدا") { fadeVolume(savedVolume, 1800) })
        content.addView(soft, matchWrap())
        val stopRow = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        stopRow.addView(button("توقف فوری") { cancelFade(); player.volume = 0f; volumeBar.progress = 0 })
        stopRow.addView(button("تایمر ۳۰ دقیقه") { startSleep(30) })
        stopRow.addView(button("لغو تایمر") { sleepTimer?.cancel(); status.text = "تایمر لغو شد" })
        content.addView(stopRow, matchWrap())
        content.addView(button("ذخیره فهرست پخش") { persistTracks(); status.text = "فهرست ذخیره شد" }, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshList()
    }

    private fun eqSlider(index: Int): SeekBar {
        return SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if (user) applyEq(index, p - 50)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
    }
    private fun applyEq(index: Int, normalized: Int) {
        try {
            val e = eq ?: return
            if (e.numberOfBands <= 0) return
            val band = min(index, e.numberOfBands.toInt() - 1).toShort()
            val range = e.bandLevelRange
            val center = ((range[0] + range[1]) / 2f)
            val level = (center + normalized * (range[1] - range[0]) / 100f).toInt()
            e.setBandLevel(band, level.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
        } catch (_: Exception) { status.text = "اکولایزر در این دستگاه در دسترس نیست" }
    }
    private fun eqFeatureSlider(onValue: (Int) -> Unit) = SeekBar(this).apply {
        max = 100; progress = 0
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) onValue(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }
    private fun initEffects() {
        releaseEffects()
        try {
            val session = player.audioSessionId
            if (session != 0) {
                eq = Equalizer(0, session).apply { enabled = true }
                bass = BassBoost(0, session).apply { enabled = true }
                virtualizer = Virtualizer(0, session).apply { enabled = true }
            }
        } catch (_: Exception) { status.text = "افکت‌های صوتی توسط دستگاه پشتیبانی نمی‌شوند" }
    }
    private fun safeSetBass(effect: BassBoost, value: Int) { try { effect.setStrength((value * 10).toShort()) } catch (_: Exception) {} }
    private fun safeSetVirtual(effect: Virtualizer, value: Int) { try { effect.setStrength((value * 10).toShort()) } catch (_: Exception) {} }

    private fun playAt(index: Int) {
        if (index !in tracks.indices) return
        cancelFade()
        player.setMediaItem(MediaItem.fromUri(tracks[index]))
        player.prepare()
        player.volume = savedVolume
        player.play()
        initEffects()
        updateCurrent()
    }
    private fun next(smooth: Boolean) {
        if (tracks.isEmpty()) return
        val target = if (shuffle && tracks.size > 1) {
            var n = tracks.indices.random(); if (n == player.currentMediaItemIndex) n = (n + 1) % tracks.size; n
        } else (max(0, player.currentMediaItemIndex) + 1) % tracks.size
        if (!smooth || !player.isPlaying) { playAt(target); return }
        cancelFade()
        fading = true
        val start = player.volume
        var step = 0
        val r = object : Runnable {
            override fun run() {
                step++
                player.volume = start * (1f - step / 8f)
                if (step < 8) handler.postDelayed(this, 45) else {
                    fading = false
                    playAt(target)
                    player.volume = 0f
                    fadeVolume(savedVolume, 450)
                }
            }
        }
        fadeRunnable = r; handler.post(r)
    }
    private fun previous() {
        if (player.currentPosition > 5000) player.seekTo(0)
        else playAt((max(0, player.currentMediaItemIndex - 1)).coerceAtLeast(0))
    }
    private fun fadeVolume(target: Float, duration: Long) {
        cancelFade()
        val start = player.volume
        val steps = 20
        var i = 0
        val r = object : Runnable {
            override fun run() {
                i++
                player.volume = start + (target - start) * (i.toFloat() / steps)
                if (i < steps) handler.postDelayed(this, duration / steps)
            }
        }
        fadeRunnable = r; handler.post(r)
    }
    private fun cancelFade() { fadeRunnable?.let { handler.removeCallbacks(it) }; fadeRunnable = null; fading = false }
    private fun startSleep(minutes: Int) {
        sleepTimer?.cancel()
        sleepTimer = object : CountDownTimer(minutes * 60_000L, 1000) {
            override fun onTick(ms: Long) { status.text = "توقف خودکار: ${ms / 60000}:${(ms / 1000) % 60}" }
            override fun onFinish() { fadeVolume(0f, 2500); status.text = "پخش به‌صورت نرم متوقف شد" }
        }.start()
    }
    private fun refreshList() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        tracks.forEachIndexed { i, uri ->
            val name = names.getOrElse(i) { "فایل صوتی ${i + 1}" }
            if (activeCategory == "همه" || name.contains(activeCategory, true)) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val item = TextView(this).apply {
                    text = "${i + 1}. $name"; textSize = 14f; setTextColor(cream); setPadding(dp(8))
                    setOnClickListener { playAt(i) }
                }
                row.addView(item, LinearLayout.LayoutParams(0, dp(48), 1f))
                row.addView(button("×") { tracks.removeAt(i); names.removeAt(i); persistTracks(); refreshList() })
                listBox.addView(row)
            }
        }
    }
    private fun updateCurrent() {
        val i = player.currentMediaItemIndex
        title.text = names.getOrNull(i) ?: "ثارالله"
        status.text = if (player.isPlaying) "در حال پخش" else "آماده پخش"
        updatePlayButton()
    }
    private fun updatePlayButton() { if (::playButton.isInitialized) playButton.text = if (player.isPlaying) "Ⅱ مکث" else "▶ پخش" }
    private fun queryName(uri: Uri): String {
        var result = "مداحی"
        try { contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) result = c.getString(idx) ?: result
            }
        } } catch (_: Exception) {}
        return result
    }
    private fun persistTracks() {
        val arr = JSONArray()
        tracks.forEachIndexed { i, uri -> arr.put(org.json.JSONObject().put("uri", uri.toString()).put("name", names.getOrElse(i) { "مداحی" })) }
        prefs.edit().putString("tracks", arr.toString()).apply()
    }
    private fun loadTracks() {
        try {
            val arr = JSONArray(prefs.getString("tracks", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); tracks.add(Uri.parse(o.getString("uri"))); names.add(o.getString("name"))
            }
        } catch (_: Exception) {}
    }
    private fun button(text: String, action: (View) -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 12f; setTextColor(gold)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
        setOnClickListener { action(this) }
    }
    private fun label(text: String) = TextView(this).apply {
        this.text = text; setTextColor(cream); textSize = 13f; gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        setPadding(dp(4))
    }
    private fun section(text: String) = TextView(this).apply {
        this.text = "✦  $text"; setTextColor(gold); textSize = 18f; gravity = Gravity.RIGHT
        setPadding(dp(8), dp(18), dp(8), dp(8))
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        setBackgroundColor(green); setPadding(dp(12))
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun releaseEffects() {
        try { eq?.release(); bass?.release(); virtualizer?.release() } catch (_: Exception) {}
        eq = null; bass = null; virtualizer = null
    }
    override fun onDestroy() {
        cancelFade(); sleepTimer?.cancel(); releaseEffects(); player.release()
        super.onDestroy()
    }
}
